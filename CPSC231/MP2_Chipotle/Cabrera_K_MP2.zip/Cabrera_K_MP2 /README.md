AUTHOR INFO
Full name: Kyla Monique Cabrera
Student ID: 2445213
Chapman Email: kycabrera@chapman.edu
Course number and section: CPSC-231-05
Assignment: MP2 - Chipotle Ordering System

ERRORS 
No errors found when compiling and running. 

SOURCES
- I had assistance from Manuel Pangelinan with establishing the format of the setters and getters.
- Classes I, Classes II, and Classes III Lecture Files
- JavaDoc Lecture File

