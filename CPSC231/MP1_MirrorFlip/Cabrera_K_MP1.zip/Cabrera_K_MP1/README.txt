AUTHOR INFO
Full name: Kyla Monique Cabrera
Student ID: 2445213
Chapman Email: kycabrera@chapman.edu
Course number and section: CPSC-231-05
Assignment: MP1 - Mirror Flipping Images 

ERRORS 
No errors found when compiling and running. 

SOURCES
- I had assistance from Manuel Pangelinan in establishing the format of the methods.
