public class MirrorFlipImage{ //initialize class. 

    private static void displayImage(char[][] image) { // code to display regular image. It will create a 2D array with "char [][]" by taking in two values, one for rows and one for columns.
        for (int r = 0; r < image.length; r++){ // set rows = 0 and code will run as long as the current row is less than the amount of rows in the array. Increment by 1 row each time.
            for (int c = 0; c < image[0].length; c++){ // set columns = 0 and code will run as long as current colum is less than the amount of columns in the array. Increment by 1 column each time. 
                System.out.print(image[r][c] + " "); // Print out rows and columns exactly how they were created adding a space after every character for organization. 
            }
            System.out.println(); // Prints out original image. 
        }

    }
    private static char[][] horizontalMirror(char[][] image){ // method to display image horizontally mirrored. 
        char[][] hArray = new char [image.length][image[0].length]; //create a new 2D array that has the same parameters as the original image. 
        for (int r = 0; r < image.length; r++){ // as long as the current row is less than the amount of rows in the array. Increment by 1 row each time. 
            for (int c = 0; c < image[0].length; c++){// as long as the current column is less than the amount of rows in the array. Increment by 1 column each time. 
                hArray[r][c] = image[image.length - 1 - r][c]; // for the new array, subrtact 1 from "image.length" which represents the rows and it will change the order of the rows within each column.
            }
        }
        return hArray;
    }
    private static char[][] verticalMirror(char[][] image){
        char[][] vArray = new char[image.length][image[0].length]; // create a new 2D array that has the same paramers as the original image.
        for (int r = 0; r < image.length; r++){
            for (int c = 0; c< image[0].length; c++){
                vArray[r][c] = image[r][image[0].length - 1 - c];// for the new array, subrtact 1 from "image.length[0]" which represents the columns and it will change the order of the columns within each row.
            }
        }
        return vArray;
    }

    public static void main(String[] args) { // main method signature where code starts to run. 
        char[][] image = { // original image to be displayed and altered. 
            {'#', 'M', '#', '#', '#'},
            {'#', ' ', ' ', ' ', '#'},
            {'#', ' ', 'K', ' ', '#'},
            {'*', ' ', ' ', ' ', 'B'},
            {'#', ' ', ' ', ' ', '#'},
            {'#', ' ', ' ', ' ', '#'},
            {'#', '#', '#', 'C', '#'},
        }; 

        System.out.println("Original Image:"); 
        displayImage(image); // prints out original image. 

        System.out.println("Horizontally flipped image:"); 
        displayImage(horizontalMirror(image)); // prints out horizontally flipped image. 

        System.out.println("Vertically flipped image:"); 
        displayImage(verticalMirror(image));// prints out vertically flipped image.

        System.out.println("Horizontally and then Vertically flipped image:"); 
        displayImage(horizontalMirror(verticalMirror(image)));// prints out image that is both horizontally and vertically flipped. 

    }
}